<!-- BARRA DE NAVEGACIÓN PRINCIPAL -->
<nav id="barra-principal" class="barra-principal bg-dark text-white text-center py-2">
  <a href="<?= base_url('catalogo') ?>">CATÁLOGO DE VEHÍCULOS</a>
  <a href="<?= base_url('servicios') ?>">SERVICIOS</a>
  <a href="<?= base_url('experiencias') ?>">EXPERIENCIA DE LOS CLIENTES</a>
  <a href="<?= base_url('informacion_corporativa') ?>">INFORMACIÓN CORPORATIVA</a>
  <a href="<?= base_url('compraYVenta') ?>">OPCIONES DE COMPRA/VENTA</a>
</nav>